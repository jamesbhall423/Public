package james.games.manuver;

import java.awt.Frame;

public class GlobalFrame extends Frame {
	private CreatorInterface creator;	
	/**
	 * Method GlobalFrame
	 *
	 *
	 * @param creator
	 *
	 */
	public GlobalFrame(CreatorInterface creator) {
		// TODO: Add your code here
	}	
}
