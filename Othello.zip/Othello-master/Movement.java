
public class Movement {
	public final int x;
	public final int y;	
	/**
	 * Method Movement
	 *
	 *
	 * @param x
	 * @param y
	 *
	 */
	public Movement(int x, int y) {
		this.x=x;
		this.y=y;
	}	
}
