package school.team.musictuner;
/*
* An interface for the activity to obtain settings from the user.
* Works with Settings object.
 */
public interface SettingsDisplay {

}
