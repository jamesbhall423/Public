package school.team.musictuner;
/*
* An interface that represents an activity to train the Tuner to the precise overtones of a given instrument.
* Works with Tuner object
* Stretch
 */
public interface TrainingDisplay {
    
}
