package school.team.musictuner;

public class Tune {
}
