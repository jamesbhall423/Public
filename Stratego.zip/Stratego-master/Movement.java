// represents the movement of a peice from one place to another

//constructor - line 11;

class Movement {
	public int X1;
	public int X2;
	public int Y1;
	public int Y2;
	public double Value;
	public Movement(int x1, int y1, int x2, int y2, double value) {
		X1 = x1;
		X2 = x2;
		Y1 = y1;
		Y2 = y2;
		Value = value;
	}
}
