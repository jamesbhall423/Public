// Everything about a mapButton

//constructor - line 9;

class squareValues {
	public int X;
	public int Y;
	public int Contents;
	public squareValues(int x, int y, int C) {
		X = x;
		Y = y;
		Contents = C;
	}
}
